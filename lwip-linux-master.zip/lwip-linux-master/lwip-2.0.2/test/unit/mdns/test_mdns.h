#ifndef LWIP_HDR_TEST_MDNS_H__
#define LWIP_HDR_TEST_MDNS_H__

#include "../lwip_check.h"

Suite* mdns_suite(void);

#endif
